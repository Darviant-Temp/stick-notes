package com.stick.notes

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Ui {
    val BG = Color.parseColor("#0D0D0F")
    val SURF = Color.parseColor("#18181B")
    val TEXT = Color.parseColor("#F5F5F6")
    val MUTE = Color.parseColor("#8D8D93")
    val LINE = Color.parseColor("#1AFFFFFF")

    fun blend(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * t + Color.red(b) * (1 - t)).toInt()
        val g = (Color.green(a) * t + Color.green(b) * (1 - t)).toInt()
        val bl = (Color.blue(a) * t + Color.blue(b) * (1 - t)).toInt()
        return Color.rgb(r, g, bl)
    }

    fun rounded(fill: Int, radiusPx: Float, strokePx: Int = 0, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = radiusPx
        if (strokePx > 0) d.setStroke(strokePx, stroke)
        return d
    }

    fun circle(fill: Int, strokePx: Int = 0, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(fill)
        if (strokePx > 0) d.setStroke(strokePx, stroke)
        return d
    }
}
