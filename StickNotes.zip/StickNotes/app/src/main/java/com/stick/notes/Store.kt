package com.stick.notes

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Note(val id: String, var title: String, var body: String, var color: Int)

val Note.rgb: Int get() = Store.COLORS[color.coerceIn(0, Store.COLORS.size - 1)]

object Store {
    val COLORS = intArrayOf(
        0xFFF5C84C.toInt(), 0xFF6FD3A8.toInt(), 0xFF74B9FF.toInt(),
        0xFFFF8FA8.toInt(), 0xFFB5A1FF.toInt()
    )

    private fun p(c: Context) = c.getSharedPreferences("stick", Context.MODE_PRIVATE)

    fun notes(c: Context): MutableList<Note> {
        val raw = p(c).getString("notes", null)
        if (raw == null) {
            val seed = mutableListOf(
                Note(UUID.randomUUID().toString(), "Welcome",
                    "Tap + to write a note. Tap Add widget to put one on your home screen.", 0)
            )
            save(c, seed)
            return seed
        }
        val out = mutableListOf<Note>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Note(o.getString("id"), o.optString("title"), o.optString("body"), o.optInt("c", 0)))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(c: Context, list: List<Note>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("c", it.color))
        }
        p(c).edit().putString("notes", a.toString()).apply()
    }

    fun upsert(c: Context, n: Note) {
        val list = notes(c)
        val i = list.indexOfFirst { it.id == n.id }
        if (i >= 0) list[i] = n else list.add(0, n)
        save(c, list)
    }

    fun delete(c: Context, id: String) {
        save(c, notes(c).filter { it.id != id })
    }

    fun widgetNote(c: Context, widgetId: Int): String? = p(c).getString("w$widgetId", null)

    fun setWidgetNote(c: Context, widgetId: Int, noteId: String) {
        p(c).edit().putString("w$widgetId", noteId).apply()
    }

    fun clearWidget(c: Context, widgetId: Int) {
        p(c).edit().remove("w$widgetId").apply()
    }
}
