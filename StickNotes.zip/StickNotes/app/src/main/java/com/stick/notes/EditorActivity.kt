package com.stick.notes

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.util.UUID

class EditorActivity : Activity() {
    private lateinit var note: Note
    private lateinit var titleEt: EditText
    private lateinit var bodyEt: EditText
    private lateinit var dots: LinearLayout
    private var deleted = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val id = intent.getStringExtra("id")
        val existing = Store.notes(this).firstOrNull { it.id == id }
        val isNew = existing == null
        note = existing ?: Note(UUID.randomUUID().toString(), "", "", (0 until Store.COLORS.size).random())

        window.setSoftInputMode(
            if (isNew) WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            else WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)

        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(6), dp(6), dp(6), dp(6))
        val back = label("←", 24f, Ui.TEXT)
        back.setPadding(dp(14), dp(8), dp(14), dp(8))
        back.setOnClickListener { finish() }
        dots = LinearLayout(this)
        dots.gravity = Gravity.CENTER
        val del = label("Delete", 14f, Color.parseColor("#E5484D"))
        del.setPadding(dp(14), dp(8), dp(14), dp(8))
        del.setOnClickListener {
            deleted = true
            Store.delete(this, note.id)
            NoteWidget.refreshAll(this)
            finish()
        }
        bar.addView(back)
        bar.addView(dots, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(del)
        page.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        titleEt = EditText(this)
        titleEt.setText(note.title)
        titleEt.hint = "Title"
        titleEt.textSize = 26f
        titleEt.setTypeface(null, Typeface.BOLD)
        titleEt.setTextColor(Ui.TEXT)
        titleEt.setHintTextColor(Ui.MUTE)
        titleEt.background = null
        titleEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        titleEt.setPadding(0, dp(6), 0, dp(10))
        page.addView(titleEt, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(dp(22), 0, dp(22), 0) })

        bodyEt = EditText(this)
        bodyEt.setText(note.body)
        bodyEt.hint = "Write something"
        bodyEt.textSize = 17f
        bodyEt.setTextColor(Ui.TEXT)
        bodyEt.setHintTextColor(Ui.MUTE)
        bodyEt.background = null
        bodyEt.gravity = Gravity.TOP or Gravity.START
        bodyEt.setLineSpacing(0f, 1.15f)
        bodyEt.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        bodyEt.setPadding(0, 0, 0, dp(16))
        page.addView(bodyEt, LinearLayout.LayoutParams(MATCH, 0, 1f).apply { setMargins(dp(22), 0, dp(22), 0) })

        drawDots()
        setContentView(page)
        if (isNew) titleEt.requestFocus()
    }

    private fun label(t: String, size: Float, color: Int): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        return v
    }

    private fun drawDots() {
        dots.removeAllViews()
        Store.COLORS.forEachIndexed { i, c ->
            val d = View(this)
            d.background = if (note.color == i) Ui.circle(c, dp(2), Ui.TEXT) else Ui.circle(c)
            d.setOnClickListener {
                note.color = i
                drawDots()
            }
            dots.addView(d, LinearLayout.LayoutParams(dp(24), dp(24)).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
    }

    private fun commit() {
        if (deleted) return
        note.title = titleEt.text.toString()
        note.body = bodyEt.text.toString()
        if (note.title.isBlank() && note.body.isBlank()) Store.delete(this, note.id)
        else Store.upsert(this, note)
        NoteWidget.refreshAll(this)
    }

    override fun onPause() {
        super.onPause()
        commit()
    }
}
