package com.stick.notes

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class WidgetConfigActivity : Activity() {
    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setBackgroundColor(Ui.BG)
        page.setPadding(dp(20), dp(24), dp(20), dp(20))

        val h = TextView(this)
        h.text = "Choose a note"
        h.textSize = 26f
        h.setTypeface(null, Typeface.BOLD)
        h.setTextColor(Ui.TEXT)
        h.setPadding(0, 0, 0, dp(16))
        page.addView(h)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        val notes = Store.notes(this)

        if (notes.isEmpty()) {
            val t = TextView(this)
            t.text = "No notes yet. Add the widget now, create a note in the app, then tap the widget to choose it."
            t.setTextColor(Ui.MUTE)
            t.textSize = 15f
            list.addView(t)
            list.addView(row("Add empty widget", Ui.MUTE) { done(null) })
        } else {
            notes.forEach { n -> list.addView(row(n.title.ifBlank { "Untitled" }, n.rgb) { done(n.id) }) }
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        setContentView(page)
    }

    private fun row(label: String, dotColor: Int, onClick: () -> Unit): View {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(16), dp(16), dp(16))
        r.background = Ui.rounded(Ui.SURF, dp(16).toFloat(), dp(1), Ui.LINE)
        val dot = View(this)
        dot.background = Ui.circle(dotColor)
        r.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)).apply { rightMargin = dp(14) })
        val t = TextView(this)
        t.text = label
        t.textSize = 16f
        t.setTextColor(Ui.TEXT)
        t.maxLines = 1
        r.addView(t)
        r.setOnClickListener { onClick() }
        r.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }
        return r
    }

    private fun done(noteId: String?) {
        if (noteId != null) Store.setWidgetNote(this, widgetId, noteId)
        NoteWidget.update(this, AppWidgetManager.getInstance(this), widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
