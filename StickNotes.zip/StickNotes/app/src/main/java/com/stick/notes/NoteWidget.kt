package com.stick.notes

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews

class NoteWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { Store.clearWidget(context, it) }
    }

    companion object {
        fun update(c: Context, mgr: AppWidgetManager, id: Int) {
            val note = Store.widgetNote(c, id)?.let { nid -> Store.notes(c).firstOrNull { it.id == nid } }
            val rv = RemoteViews(c.packageName, R.layout.widget_note)

            val intent: Intent
            if (note != null) {
                rv.setTextViewText(R.id.w_title, note.title.ifBlank { "Untitled" })
                rv.setTextViewText(R.id.w_body, note.body)
                rv.setInt(R.id.w_dot, "setColorFilter", note.rgb)
                rv.setViewVisibility(R.id.w_dot, View.VISIBLE)
                intent = Intent(c, EditorActivity::class.java).putExtra("id", note.id)
            } else {
                rv.setTextViewText(R.id.w_title, "Tap to choose a note")
                rv.setTextViewText(R.id.w_body, "")
                rv.setViewVisibility(R.id.w_dot, View.GONE)
                intent = Intent(c, WidgetConfigActivity::class.java)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            val pi = PendingIntent.getActivity(
                c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.w_root, pi)
            mgr.updateAppWidget(id, rv)
        }

        fun refreshAll(c: Context) {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, NoteWidget::class.java))
            ids.forEach { update(c, mgr, it) }
        }
    }
}
