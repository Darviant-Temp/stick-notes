package com.stick.notes

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var left: LinearLayout
    private lateinit var right: LinearLayout
    private lateinit var count: TextView
    private lateinit var empty: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val root = FrameLayout(this)
        root.setBackgroundColor(Ui.BG)

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(18), dp(18), dp(18), 0)

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val h1 = TextView(this)
        h1.text = "Notes"
        h1.textSize = 30f
        h1.setTypeface(null, Typeface.BOLD)
        h1.setTextColor(Ui.TEXT)
        count = TextView(this)
        count.textSize = 13f
        count.setTextColor(Ui.MUTE)
        titles.addView(h1)
        titles.addView(count)
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f))

        val pill = TextView(this)
        pill.text = "Add widget"
        pill.textSize = 14f
        pill.setTypeface(null, Typeface.BOLD)
        pill.setTextColor(Ui.BG)
        pill.setPadding(dp(16), dp(9), dp(16), dp(9))
        pill.background = Ui.rounded(Ui.TEXT, dp(30).toFloat())
        pill.setOnClickListener { addWidget() }
        header.addView(pill)
        page.addView(header, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(18) })

        empty = TextView(this)
        empty.text = "No notes yet.\nTap + to write your first one."
        empty.gravity = Gravity.CENTER
        empty.setTextColor(Ui.MUTE)
        empty.textSize = 15f
        empty.setPadding(0, dp(60), 0, 0)
        page.addView(empty, LinearLayout.LayoutParams(MATCH, WRAP))

        left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        val cols = LinearLayout(this)
        cols.setPadding(0, 0, 0, dp(110))
        cols.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        cols.addView(right, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(cols)
        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))

        val fab = TextView(this)
        fab.text = "+"
        fab.textSize = 30f
        fab.includeFontPadding = false
        fab.gravity = Gravity.CENTER
        fab.setTextColor(Ui.BG)
        fab.background = Ui.circle(Ui.TEXT)
        fab.elevation = dp(6).toFloat()
        fab.setOnClickListener { startActivity(Intent(this, EditorActivity::class.java)) }
        root.addView(
            fab,
            FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(20), dp(24))
            }
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        left.removeAllViews()
        right.removeAllViews()
        val notes = Store.notes(this)
        count.text = if (notes.size == 1) "1 note" else "${notes.size} notes"
        empty.visibility = if (notes.isEmpty()) View.VISIBLE else View.GONE
        notes.forEachIndexed { i, n -> (if (i % 2 == 0) left else right).addView(card(n)) }
    }

    private fun card(n: Note): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = Ui.rounded(Ui.blend(n.rgb, Ui.SURF, 0.22f), dp(18).toFloat(), dp(1), Ui.LINE)
        val t = TextView(this)
        t.text = n.title.ifBlank { "Untitled" }
        t.textSize = 15f
        t.setTypeface(null, Typeface.BOLD)
        t.setTextColor(Ui.TEXT)
        c.addView(t)
        if (n.body.isNotBlank()) {
            val b = TextView(this)
            b.text = n.body
            b.textSize = 13.5f
            b.setTextColor(Ui.MUTE)
            b.maxLines = 6
            b.ellipsize = TextUtils.TruncateAt.END
            b.setPadding(0, dp(5), 0, 0)
            c.addView(b)
        }
        c.setOnClickListener { startActivity(Intent(this, EditorActivity::class.java).putExtra("id", n.id)) }
        c.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
        return c
    }

    private fun addWidget() {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            mgr.requestPinAppWidget(ComponentName(this, NoteWidget::class.java), null, null)
        } else {
            Toast.makeText(
                this, "Long-press your home screen, open Widgets, and pick Stick note.", Toast.LENGTH_LONG
            ).show()
        }
    }
}
